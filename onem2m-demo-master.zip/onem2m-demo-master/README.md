# onem2m-demo
oneM2M demonstration
